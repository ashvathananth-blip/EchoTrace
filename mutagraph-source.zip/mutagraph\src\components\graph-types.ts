import type { Mutation, StatementNode } from "@/lib/types";

export type StatementNodeData = {
  statement: StatementNode;
  drift: number;
  onPath: boolean;
  active: boolean;
  depth: number;
  isRoot: boolean;
};

export type MutationEdgeData = {
  mutations: Mutation[];
  color: string;
  label: string;
  onPath: boolean;
  active: boolean;
  onSelect: () => void;
};
