"use client";

import { useMemo } from "react";
import { normalizeWord, tokenize, wordDiff } from "@/lib/diff";

export interface WordDiffProps {
  original: string;
  mutated: string;
  highlight?: { removed: string[]; added: string[] } | null;
}

function toWordSet(phrases: string[]): Set<string> {
  return new Set(tokenize(phrases.join(" ")).map(normalizeWord).filter(Boolean));
}

export default function WordDiff({ original, mutated, highlight }: WordDiffProps) {
  const ops = useMemo(() => wordDiff(original, mutated), [original, mutated]);

  const lit = useMemo(() => {
    if (!highlight) return null;
    return {
      removed: toWordSet(highlight.removed),
      added: toWordSet(highlight.added),
    };
  }, [highlight]);

  return (
    <div className="diff-wrap">
      <p className="diff">
        {ops.map((op, index) => {
          const words = tokenize(op.text).map(normalizeWord);
          const bucket =
            op.type === "delete" ? lit?.removed : op.type === "insert" ? lit?.added : undefined;
          const isLit = Boolean(bucket && words.some((word) => bucket.has(word)));

          return (
            <span
              key={`${op.type}-${index}`}
              className={`diff-token diff-${op.type}${isLit ? " is-lit" : ""}`}
            >
              {op.text}
              {index < ops.length - 1 ? " " : ""}
            </span>
          );
        })}
      </p>
      <div className="diff-key">
        <span>
          <i className="swatch swatch-del" />
          only in the previous statement
        </span>
        <span>
          <i className="swatch swatch-ins" />
          only in this statement
        </span>
      </div>
    </div>
  );
}
