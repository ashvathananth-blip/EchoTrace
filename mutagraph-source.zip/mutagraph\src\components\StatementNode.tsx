"use client";

import { Handle, Position, type NodeProps } from "@xyflow/react";
import { bandFor } from "@/lib/graph";
import { metaFor } from "@/lib/taxonomy";
import type { StatementNodeData } from "./graph-types";

export default function StatementNode({ data }: NodeProps) {
  const node = data as unknown as StatementNodeData;
  const band = bandFor(node.drift);
  const chips = [...node.statement.mutations]
    .sort((a, b) => b.severity - a.severity)
    .slice(0, 3);

  return (
    <div
      className={[
        "stmt",
        node.active ? "is-active" : "",
        node.onPath ? "is-path" : "",
        node.isRoot ? "is-root" : "",
      ]
        .filter(Boolean)
        .join(" ")}
      style={{ borderTopColor: band.color }}
    >
      <Handle type="target" position={Position.Left} className="stmt-handle" />

      <div className="stmt-top">
        <span className="band-pill" style={{ color: band.color, borderColor: band.color }}>
          {node.isRoot ? "Source" : band.label}
        </span>
        <span className="stmt-drift" title="Cumulative drift from the source">
          {node.drift}
          <span className="stmt-drift-unit">drift</span>
        </span>
      </div>

      <p className="stmt-text">{node.statement.text}</p>

      <div className="stmt-foot">
        {chips.length > 0 ? (
          <div className="chips">
            {chips.map((mutation) => {
              const meta = metaFor(mutation.kind);
              return (
                <span
                  key={`${mutation.kind}-${mutation.label}`}
                  className="chip"
                  style={{ color: meta.color, borderColor: meta.color }}
                  title={mutation.label}
                >
                  <span className="chip-dot" style={{ background: meta.color }} />
                  {meta.label}
                </span>
              );
            })}
            {node.statement.mutations.length > 3 ? (
              <span className="chip chip-more">+{node.statement.mutations.length - 3}</span>
            ) : null}
          </div>
        ) : (
          <span className="stmt-note">baseline reading</span>
        )}
      </div>

      <Handle type="source" position={Position.Right} className="stmt-handle" />
    </div>
  );
}
