import { MUTATION_KINDS, MUTATION_META } from "@/lib/taxonomy";

export default function Legend() {
  return (
    <details className="legend" open>
      <summary>Mutation vocabulary ({MUTATION_KINDS.length})</summary>
      <ul>
        {MUTATION_KINDS.map((kind) => {
          const meta = MUTATION_META[kind];
          return (
            <li key={kind}>
              <span className="legend-dot" style={{ background: meta.color }} />
              <div>
                <strong>{meta.label}</strong>
                <p>{meta.blurb}</p>
              </div>
            </li>
          );
        })}
      </ul>
    </details>
  );
}
