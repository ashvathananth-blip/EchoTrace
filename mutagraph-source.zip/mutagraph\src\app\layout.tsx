import type { ReactNode } from "react";
import type { Metadata, Viewport } from "next";
import "@xyflow/react/dist/style.css";
import "./globals.css";

export const metadata: Metadata = {
  title: "Mutagraph — trace how a statement becomes misleading",
  description:
    "A mutation graph for misinformation: enter a source statement and its rewrites, and see exactly which words turned a correlation into a cause.",
};

export const viewport: Viewport = {
  themeColor: "#070b10",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
