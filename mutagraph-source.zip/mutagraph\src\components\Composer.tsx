"use client";

import { useState, type FormEvent } from "react";
import { DEMO_INPUT } from "@/lib/examples";
import type { Chain } from "@/lib/types";

interface Row {
  id: string;
  text: string;
  parentId: string;
}

export interface ComposerProps {
  onChain: (chain: Chain) => void;
}

const MAX_ROWS = 6;

function rowsFromDemo(): Row[] {
  return DEMO_INPUT.rewrites.map((rewrite) => ({
    id: rewrite.id,
    text: rewrite.text,
    parentId: rewrite.parentId,
  }));
}

function newRow(index: number): Row {
  return { id: `row-${Date.now().toString(36)}-${index}`, text: "", parentId: "root" };
}

export default function Composer({ onChain }: ComposerProps) {
  const [original, setOriginal] = useState(DEMO_INPUT.original);
  const [rows, setRows] = useState<Row[]>(rowsFromDemo);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const updateRow = (id: string, patch: Partial<Row>) => {
    setRows((current) =>
      current.map((row) => (row.id === id ? { ...row, ...patch } : row)),
    );
  };

  const addRow = () => {
    if (rows.length >= MAX_ROWS) return;
    setRows((current) => [...current, newRow(current.length)]);
  };

  const removeRow = (id: string) => {
    setRows((current) =>
      current
        .filter((row) => row.id !== id)
        .map((row) => (row.parentId === id ? { ...row, parentId: "root" } : row)),
    );
  };

  const loadDemo = () => {
    setOriginal(DEMO_INPUT.original);
    setRows(rowsFromDemo());
    setError(null);
  };

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (busy) return;

    setError(null);

    if (original.trim().length < 12) {
      setError("Start with a full sentence — at least a dozen characters.");
      return;
    }

    const filled = rows.filter((row) => row.text.trim().length > 0);
    if (filled.length === 0) {
      setError("Add at least one rewritten version to compare.");
      return;
    }
    const tooShort = filled.find((row) => row.text.trim().length < 6);
    if (tooShort) {
      setError("Every rewrite needs at least a few words.");
      return;
    }

    const indexById = new Map(
      filled.map((row, index): [string, number] => [row.id, index + 1]),
    );
    const rewrites = filled.map((row, index) => {
      const parentIndex = indexById.get(row.parentId);
      return {
        id: `r${index + 1}`,
        text: row.text.trim(),
        parentId: parentIndex ? `r${parentIndex}` : "root",
      };
    });

    setBusy(true);
    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ original: original.trim(), rewrites }),
      });

      const data = (await response.json()) as { chain?: Chain; error?: string };
      if (!response.ok || !data.chain) {
        throw new Error(data.error ?? "The analysis failed. Try again.");
      }
      onChain(data.chain);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Something went wrong.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <form className="composer" onSubmit={submit}>
      <div className="rail-head">
        <h2>Compose a chain</h2>
        <button type="button" className="link-btn" onClick={loadDemo}>
          Reset to demo
        </button>
      </div>

      <div className="field">
        <label htmlFor="original">Original statement</label>
        <textarea
          id="original"
          value={original}
          rows={3}
          maxLength={700}
          placeholder="A study found an association between…"
          onChange={(event) => setOriginal(event.target.value)}
        />
      </div>

      {rows.map((row, index) => {
        const parents = rows.slice(0, index);
        return (
          <div className="rewrite-row" key={row.id}>
            <div className="rewrite-head">
              <span>Rewrite {index + 1}</span>
              {rows.length > 1 ? (
                <button
                  type="button"
                  className="icon-btn"
                  onClick={() => removeRow(row.id)}
                  aria-label={`Remove rewrite ${index + 1}`}
                >
                  ×
                </button>
              ) : null}
            </div>

            <textarea
              value={row.text}
              rows={2}
              maxLength={700}
              placeholder="How was it rephrased?"
              aria-label={`Rewrite ${index + 1} text`}
              onChange={(event) => updateRow(row.id, { text: event.target.value })}
            />

            <label className="parent-select">
              <span>derived from</span>
              <select
                value={row.parentId}
                aria-label={`Parent of rewrite ${index + 1}`}
                onChange={(event) => updateRow(row.id, { parentId: event.target.value })}
              >
                <option value="root">Original statement</option>
                {parents.map((candidate) => (
                  <option key={candidate.id} value={candidate.id}>
                    Rewrite {rows.indexOf(candidate) + 1}
                    {candidate.text ? ` — ${candidate.text.slice(0, 32)}` : ""}
                  </option>
                ))}
              </select>
            </label>
          </div>
        );
      })}

      <div className="composer-actions">
        <button
          type="button"
          className="btn small"
          onClick={addRow}
          disabled={rows.length >= MAX_ROWS}
        >
          + Add rewrite
        </button>
      </div>

      {error ? <p className="error">{error}</p> : null}

      <button type="submit" className="btn primary composer-submit" disabled={busy}>
        {busy ? "Tracing…" : "Trace the mutation"}
      </button>

      <p className="hint">
        Branch by pointing a rewrite at another rewrite. Without an API key the
        built-in analyser runs; with <code>ANTHROPIC_API_KEY</code> set, the model reads
        the same diff and explains it.
      </p>
    </form>
  );
}
