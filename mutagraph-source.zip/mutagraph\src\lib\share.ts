import type { Chain } from "./types";

function toBase64Url(bytes: Uint8Array): string {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function fromBase64Url(value: string): Uint8Array {
  const padded = value.replace(/-/g, "+").replace(/_/g, "/");
  const binary = atob(padded.padEnd(Math.ceil(padded.length / 4) * 4, "="));
  return Uint8Array.from(binary, (char) => char.charCodeAt(0));
}

export function encodeChain(chain: Chain): string {
  const payload = {
    t: chain.title,
    o: chain.original,
    v: chain.verdict,
    e: chain.engine,
    n: chain.nodes.map((node) => ({
      i: node.id,
      p: node.parentId,
      x: node.text,
      s: node.source,
      m: node.mutations.map((mutation) => ({
        k: mutation.kind,
        s: mutation.severity,
        l: mutation.label,
        d: mutation.explanation,
        r: mutation.evidence.removed,
        a: mutation.evidence.added,
        dir: mutation.direction ?? null,
      })),
    })),
  };

  return toBase64Url(new TextEncoder().encode(JSON.stringify(payload)));
}

interface EncodedMutation {
  k: Chain["nodes"][number]["mutations"][number]["kind"];
  s: number;
  l: string;
  d: string;
  r: string[];
  a: string[];
  dir?: "up" | "down" | "shift" | null;
}

interface EncodedNode {
  i: string;
  p: string | null;
  x: string;
  s: Chain["nodes"][number]["source"];
  m: EncodedMutation[];
}

interface EncodedChain {
  t?: string;
  o?: string;
  v?: string;
  e?: Chain["engine"];
  n?: EncodedNode[];
}

export function decodeChain(payload: string): Chain | null {
  try {
    const json = new TextDecoder().decode(fromBase64Url(payload));
    const data = JSON.parse(json) as EncodedChain;
    if (!data || !Array.isArray(data.n) || data.n.length === 0) return null;

    const nodes = data.n
      .filter((node) => typeof node.x === "string" && typeof node.i === "string")
      .map((node) => ({
        id: node.i,
        parentId: node.p ?? null,
        text: node.x,
        source: node.s ?? "curated",
        mutations: (node.m ?? []).map((mutation) => ({
          kind: mutation.k,
          severity: Math.max(0, Math.min(100, Number(mutation.s) || 0)),
          label: String(mutation.l ?? "Change"),
          explanation: String(mutation.d ?? ""),
          direction: mutation.dir ?? undefined,
          evidence: {
            removed: Array.isArray(mutation.r) ? mutation.r.map(String) : [],
            added: Array.isArray(mutation.a) ? mutation.a.map(String) : [],
          },
        })),
      }));

    if (nodes.length === 0) return null;

    return {
      id: "shared",
      title: data.t ?? "Shared chain",
      original: data.o ?? nodes[0].text,
      nodes,
      verdict: data.v ?? "",
      engine: data.e ?? "curated",
    };
  } catch {
    return null;
  }
}

export function buildShareUrl(chain: Chain): string {
  const encoded = encodeChain(chain);
  if (typeof window === "undefined") return `#c=${encoded}`;
  const { origin, pathname } = window.location;
  return `${origin}${pathname}#c=${encoded}`;
}
