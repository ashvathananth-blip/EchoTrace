"use client";

import {
  BaseEdge,
  EdgeLabelRenderer,
  getBezierPath,
  type EdgeProps,
} from "@xyflow/react";
import type { MutationEdgeData } from "./graph-types";

export default function MutationEdge(props: EdgeProps) {
  const {
    id,
    sourceX,
    sourceY,
    targetX,
    targetY,
    sourcePosition,
    targetPosition,
    markerEnd,
    data,
  } = props;

  const edge = data as unknown as MutationEdgeData | undefined;
  const color = edge?.color ?? "#64748b";

  const [path, labelX, labelY] = getBezierPath({
    sourceX,
    sourceY,
    targetX,
    targetY,
    sourcePosition,
    targetPosition,
    curvature: 0.3,
  });

  return (
    <>
      <BaseEdge
        id={id}
        path={path}
        markerEnd={markerEnd}
        style={{
          stroke: color,
          strokeWidth: edge?.active ? 2.6 : 1.8,
          opacity: edge?.onPath ? 0.95 : 0.45,
        }}
      />
      {edge ? (
        <EdgeLabelRenderer>
          <button
            type="button"
            className={`edge-label${edge.active ? " is-active" : ""}`}
            style={{
              transform: `translate(-50%, -50%) translate(${labelX}px, ${labelY}px)`,
              borderColor: color,
              color,
            }}
            onClick={(event) => {
              event.stopPropagation();
              edge.onSelect();
            }}
          >
            <span className="edge-dot" style={{ background: color }} />
            {edge.label}
          </button>
        </EdgeLabelRenderer>
      ) : null}
    </>
  );
}
