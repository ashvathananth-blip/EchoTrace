"use client";

import { useEffect, useMemo } from "react";
import {
  Background,
  Controls,
  MarkerType,
  ReactFlow,
  useNodesState,
  type Edge,
  type EdgeTypes,
  type Node,
  type NodeTypes,
} from "@xyflow/react";
import { NODE_WIDTH, ancestryIds, layoutChain } from "@/lib/graph";
import { dominantMutation, metaFor } from "@/lib/taxonomy";
import type { Chain } from "@/lib/types";
import MutationEdge from "./MutationEdge";
import StatementNode from "./StatementNode";
import type { MutationEdgeData, StatementNodeData } from "./graph-types";

const nodeTypes: NodeTypes = { statement: StatementNode };
const edgeTypes: EdgeTypes = { mutation: MutationEdge };

export interface GraphProps {
  chain: Chain;
  selectedId: string;
  onSelect: (id: string) => void;
}

export default function Graph({ chain, selectedId, onSelect }: GraphProps) {
  const layout = useMemo(() => layoutChain(chain), [chain]);
  const pathIds = useMemo(
    () => new Set(ancestryIds(selectedId, chain.nodes)),
    [selectedId, chain.nodes],
  );

  const [nodes, setNodes, onNodesChange] = useNodesState<Node<StatementNodeData>>(
    layout.nodes.map((entry) => ({
      id: entry.node.id,
      type: "statement",
      position: { x: entry.x, y: entry.y },
      style: { width: NODE_WIDTH },
      draggable: true,
      data: {
        statement: entry.node,
        drift: entry.drift,
        onPath: true,
        active: entry.node.id === selectedId,
        depth: entry.depth,
        isRoot: !entry.node.parentId,
      },
    })),
  );

  useEffect(() => {
    setNodes((current) =>
      current.map((node) => ({
        ...node,
        data: {
          ...node.data,
          onPath: pathIds.has(node.id),
          active: node.id === selectedId,
        },
      })),
    );
  }, [pathIds, selectedId, setNodes]);

  const edges = useMemo<Edge<MutationEdgeData>[]>(
    () =>
      layout.nodes
        .filter((entry) => entry.node.parentId)
        .map((entry) => {
          const dominant = dominantMutation(entry.node.mutations);
          const color = dominant ? metaFor(dominant.kind).color : "#64748b";
          const label = dominant
            ? `${metaFor(dominant.kind).label}${
                entry.node.mutations.length > 1
                  ? ` +${entry.node.mutations.length - 1}`
                  : ""
              }`
            : "Reworded";

          return {
            id: `${entry.node.parentId}-${entry.node.id}`,
            source: entry.node.parentId as string,
            target: entry.node.id,
            type: "mutation",
            data: {
              mutations: entry.node.mutations,
              color,
              label,
              onPath: pathIds.has(entry.node.id),
              active: entry.node.id === selectedId,
              onSelect: () => onSelect(entry.node.id),
            },
            markerEnd: {
              type: MarkerType.ArrowClosed,
              color,
              width: 18,
              height: 18,
            },
          };
        }),
    [layout, pathIds, selectedId, onSelect],
  );

  return (
    <ReactFlow
      nodes={nodes}
      edges={edges}
      nodeTypes={nodeTypes}
      edgeTypes={edgeTypes}
      onNodesChange={onNodesChange}
      onNodeClick={(_, node) => onSelect(node.id)}
      onEdgeClick={(_, edge) => onSelect(edge.target)}
      onPaneClick={() => onSelect(layout.rootId)}
      elementsSelectable={false}
      nodesConnectable={false}
      minZoom={0.2}
      maxZoom={1.6}
      fitView
      fitViewOptions={{ padding: 0.28, maxZoom: 1.05 }}
      className="graph"
    >
      <Background gap={26} size={1.1} color="#1c2a37" />
      <Controls showInteractive={false} position="bottom-right" />
    </ReactFlow>
  );
}
