"use client";

import { useMemo, useState } from "react";
import { ancestryIds, bandFor, layoutChain } from "@/lib/graph";
import { dominantMutation, metaFor, severityTier } from "@/lib/taxonomy";
import type { Chain, Mutation, StatementNode } from "@/lib/types";
import WordDiff from "./WordDiff";

export interface InspectorProps {
  chain: Chain;
  nodeId: string;
  onSelect: (id: string) => void;
}

function directionGlyph(mutation: Mutation): string | null {
  if (mutation.direction === "up") return "↑";
  if (mutation.direction === "down") return "↓";
  if (mutation.direction === "shift") return "⇄";
  return null;
}

export default function Inspector({ chain, nodeId, onSelect }: InspectorProps) {
  const layout = useMemo(() => layoutChain(chain), [chain]);
  const entry = layout.byId.get(nodeId) ?? layout.nodes[0];
  const node = entry.node;
  const parent = node.parentId
    ? chain.nodes.find((candidate) => candidate.id === node.parentId)
    : undefined;

  const band = bandFor(entry.drift);
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const mutations = useMemo(
    () => [...node.mutations].sort((a, b) => b.severity - a.severity),
    [node.mutations],
  );

  const active = activeIndex !== null ? mutations[activeIndex] ?? null : null;

  const trail = useMemo(() => {
    const ids = ancestryIds(node.id, chain.nodes);
    return ids
      .map((id) => chain.nodes.find((candidate) => candidate.id === id))
      .filter((candidate): candidate is StatementNode => Boolean(candidate));
  }, [chain.nodes, node.id]);

  return (
    <div className="inspector">
      <div className="inspector-head">
        <div>
          <span className="eyebrow">
            {parent ? `Step ${entry.depth}` : "Source statement"}
          </span>
          <h2>{parent ? "What changed" : "The baseline"}</h2>
        </div>
        <span className="band-pill" style={{ color: band.color, borderColor: band.color }}>
          {band.label}
        </span>
      </div>

      <div className="drift-block">
        <div className="drift-row">
          <span>Drift from source</span>
          <strong>
            {entry.drift}
            <small>/100</small>
          </strong>
        </div>
        <div className="drift-track">
          <span style={{ width: `${Math.max(3, entry.drift)}%`, background: band.color }} />
        </div>
        <p className="drift-note">{band.description}</p>
      </div>

      <p className="stmt-full">{node.text}</p>

      {parent ? (
        <section className="section">
          <h3>
            Word-level change <span>vs the statement it came from</span>
          </h3>
          <WordDiff
            original={parent.text}
            mutated={node.text}
            highlight={active ? active.evidence : null}
          />
        </section>
      ) : (
        <section className="section">
          <h3>Where to look</h3>
          <p className="body-copy">
            {chain.message ??
              "Every branch is measured against this sentence: strength, scope, attribution and the qualifiers that limit it. Select a rewrite to see what moved."}
          </p>
        </section>
      )}

      <section className="section">
        <h3>
          Transformations <span>{mutations.length > 0 ? mutations.length : "none"}</span>
        </h3>

        {mutations.length === 0 ? (
          <p className="body-copy">
            Nothing was changed here. This is the reference reading that every other branch
            is compared against.
          </p>
        ) : (
          <ol className="mutation-list">
            {mutations.map((mutation, index) => {
              const meta = metaFor(mutation.kind);
              const glyph = directionGlyph(mutation);
              const isActive = activeIndex === index;
              return (
                <li
                  key={`${mutation.kind}-${index}`}
                  className={`mutation-card tier-${severityTier(mutation.severity)}${
                    isActive ? " is-active" : ""
                  }`}
                  style={{ borderLeftColor: meta.color }}
                  onMouseEnter={() => setActiveIndex(index)}
                  onMouseLeave={() => setActiveIndex(null)}
                >
                  <div className="mutation-top">
                    <span className="mutation-kind" style={{ color: meta.color }}>
                      {meta.label}
                    </span>
                    <span className="severity" title={`Severity ${mutation.severity} of 100`}>
                      <span className="severity-value">{mutation.severity}</span>
                      <span className="severity-track">
                        <span
                          style={{
                            width: `${Math.max(4, mutation.severity)}%`,
                            background: meta.color,
                          }}
                        />
                      </span>
                    </span>
                  </div>

                  <h4>
                    {mutation.label}
                    {glyph ? <span className="dir">{glyph}</span> : null}
                  </h4>
                  <p>{mutation.explanation}</p>

                  {mutation.evidence.removed.length > 0 ||
                  mutation.evidence.added.length > 0 ? (
                    <div className="evidence">
                      {mutation.evidence.removed.length > 0 ? (
                        <div className="evidence-row">
                          <span className="evidence-tag evidence-del">removed</span>
                          <span className="evidence-text evidence-del-text">
                            {mutation.evidence.removed.map((phrase) => `“${phrase}”`).join(" · ")}
                          </span>
                        </div>
                      ) : null}
                      {mutation.evidence.added.length > 0 ? (
                        <div className="evidence-row">
                          <span className="evidence-tag evidence-add">added</span>
                          <span className="evidence-text evidence-add-text">
                            {mutation.evidence.added.map((phrase) => `“${phrase}”`).join(" · ")}
                          </span>
                        </div>
                      ) : null}
                    </div>
                  ) : null}
                </li>
              );
            })}
          </ol>
        )}
      </section>

      <section className="section">
        <h3>Provenance</h3>
        <ol className="provenance">
          {trail.map((step, index) => {
            const stepMutations = step.mutations;
            const dominant = dominantMutation(stepMutations);
            const label = !step.parentId
              ? "Source statement"
              : dominant
                ? dominant.label
                : "Reworded";
            const color = dominant ? metaFor(dominant.kind).color : "#64788c";
            return (
              <li key={step.id}>
                <span className="step-index">{index === 0 ? "0" : index}</span>
                <button
                  type="button"
                  onClick={() => onSelect(step.id)}
                  aria-current={step.id === node.id}
                >
                  {step.text}
                  <span className="step-note" style={{ color }}>
                    {label}
                  </span>
                </button>
              </li>
            );
          })}
        </ol>
      </section>

      <div className="inspector-foot">
        <span>
          {chain.engine === "anthropic"
            ? "Model analysis (Anthropic)"
            : chain.engine === "heuristic"
              ? "Offline linguistic analysis"
              : "Curated demonstration chain"}
        </span>
        {chain.message ? <span className="inspector-foot-note">{chain.message}</span> : null}
      </div>
    </div>
  );
}
