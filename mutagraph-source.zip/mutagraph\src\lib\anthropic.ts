import { MUTATION_KINDS, MUTATION_META, isMutationKind } from "./taxonomy";
import type { Mutation } from "./types";

const ANTHROPIC_URL = "https://api.anthropic.com/v1/messages";
const ANTHROPIC_VERSION = "2023-06-01";
const DEFAULT_MODEL = "claude-sonnet-4-5";
const TIMEOUT_MS = 30_000;

export interface ClassifyEdge {
  id: string;
  parentText: string;
  text: string;
}

export interface ClassifyResult {
  edges: Map<string, Mutation[]>;
  model: string;
}

const TAXONOMY_GUIDE = MUTATION_KINDS.filter((kind) => kind !== "faithful")
  .map((kind) => `- ${kind}: ${MUTATION_META[kind].blurb}`)
  .join("\n");

const SYSTEM_PROMPT = `You are a media-literacy analyst who traces how an accurate statement turns into a misleading one.

You receive a chain of statements. Each rewrite has a parent. For every rewrite, list the transformations that change what a careful reader would conclude, compared ONLY with its parent.

Transformation kinds:
${TAXONOMY_GUIDE}
- faithful: rewording that preserves strength, scope and evidence.

Rules:
1. Use only the kinds above. Pick the specific mechanism, not a generic "misleading".
2. severity 0-100: how much this single transformation changes the conclusion. 20 = stylistic, 60 = a reader would draw a stronger conclusion, 85+ = a different claim.
3. Evidence must be exact substrings of the two statements. "removed" comes from the parent, "added" from the rewrite. Never invent quotes; use an empty array when nothing fits.
4. explanation: two or three sentences, concrete, naming the words responsible and what a reader now believes that the source did not support. No hedging about being an AI. No moralising.
5. Do not add transformations that are not present. A faithful rewrite gets exactly one "faithful" record with severity below 15.
6. Never claim a real institution or scientist said something; describe attribution, do not endorse it.`;

const TOOL = {
  name: "report_mutations",
  description:
    "Report every semantic transformation between each rewrite and its parent statement.",
  input_schema: {
    type: "object",
    properties: {
      edges: {
        type: "array",
        items: {
          type: "object",
          properties: {
            id: { type: "string", description: "The pair id provided in the prompt." },
            mutations: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  kind: { type: "string", enum: MUTATION_KINDS },
                  severity: { type: "number" },
                  direction: { type: "string", enum: ["up", "down", "shift"] },
                  label: { type: "string", description: "At most 6 words." },
                  explanation: { type: "string" },
                  removed: { type: "array", items: { type: "string" } },
                  added: { type: "array", items: { type: "string" } },
                },
                required: [
                  "kind",
                  "severity",
                  "label",
                  "explanation",
                  "removed",
                  "added",
                ],
              },
            },
          },
          required: ["id", "mutations"],
        },
      },
    },
    required: ["edges"],
  },
} as const;

interface ContentBlock {
  type?: string;
  input?: unknown;
}

interface MessagesResponse {
  content?: ContentBlock[];
  model?: string;
  error?: { message?: string; type?: string };
}

function clampText(value: unknown, max: number): string {
  return typeof value === "string" ? value.replace(/\s+/g, " ").trim().slice(0, max) : "";
}

function asStringArray(value: unknown, max = 6): string[] {
  if (!Array.isArray(value)) return [];
  return value
    .map((item) => clampText(item, 160))
    .filter((item) => item.length > 0)
    .slice(0, max);
}

function normaliseMutation(raw: unknown): Mutation | null {
  if (!raw || typeof raw !== "object") return null;
  const record = raw as Record<string, unknown>;
  if (!isMutationKind(record.kind)) return null;

  const severityRaw = Number(record.severity);
  const severity = Number.isFinite(severityRaw)
    ? Math.max(0, Math.min(100, Math.round(severityRaw)))
    : 50;

  const explanation = clampText(record.explanation, 600);
  const label = clampText(record.label, 60) || MUTATION_META[record.kind].label;
  if (explanation.length < 10) return null;

  const direction =
    record.direction === "up" || record.direction === "down" || record.direction === "shift"
      ? record.direction
      : undefined;

  return {
    kind: record.kind,
    severity,
    label,
    explanation,
    direction,
    evidence: {
      removed: asStringArray(record.removed),
      added: asStringArray(record.added),
    },
  };
}

export async function classifyEdges(edges: ClassifyEdge[]): Promise<ClassifyResult | null> {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) return null;

  const model = process.env.ANTHROPIC_MODEL?.trim() || DEFAULT_MODEL;

  const prompt = [
    "Compare each rewrite with the statement it was derived from.",
    "",
    "<statements>",
    ...edges.map((edge) =>
      [
        `<pair id="${edge.id}">`,
        `  <source>${edge.parentText}</source>`,
        `  <rewrite>${edge.text}</rewrite>`,
        `</pair>`,
      ].join("\n"),
    ),
    "</statements>",
    "",
    `Return one record for each of the ${edges.length} pair ids via the report_mutations tool.`,
  ].join("\n");

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), TIMEOUT_MS);

  try {
    const response = await fetch(ANTHROPIC_URL, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": ANTHROPIC_VERSION,
      },
      body: JSON.stringify({
        model,
        max_tokens: 2048,
        temperature: 0,
        system: SYSTEM_PROMPT,
        tools: [TOOL],
        tool_choice: { type: "tool", name: TOOL.name },
        messages: [{ role: "user", content: prompt }],
      }),
      signal: controller.signal,
    });

    if (!response.ok) {
      const detail = await response.text().catch(() => "");
      console.warn(
        `[mutagraph] Anthropic request failed (${response.status}): ${detail.slice(0, 300)}`,
      );
      return null;
    }

    const payload = (await response.json()) as MessagesResponse;
    const block = payload.content?.find((item) => item.type === "tool_use");
    const input = block?.input as { edges?: unknown } | undefined;
    if (!input || !Array.isArray(input.edges)) return null;

    const map = new Map<string, Mutation[]>();

    for (const rawEdge of input.edges) {
      if (!rawEdge || typeof rawEdge !== "object") continue;
      const record = rawEdge as Record<string, unknown>;
      const id = clampText(record.id, 80);
      if (!id) continue;
      const list = Array.isArray(record.mutations) ? record.mutations : [];
      const mutations = list
        .map(normaliseMutation)
        .filter((mutation): mutation is Mutation => mutation !== null)
        .sort((a, b) => b.severity - a.severity)
        .slice(0, 5);
      if (mutations.length > 0) map.set(id, mutations);
    }

    if (map.size === 0) return null;
    return { edges: map, model: payload.model ?? model };
  } catch (error) {
    const reason = error instanceof Error ? error.message : "unknown error";
    console.warn(`[mutagraph] Anthropic call failed: ${reason}`);
    return null;
  } finally {
    clearTimeout(timeout);
  }
}
