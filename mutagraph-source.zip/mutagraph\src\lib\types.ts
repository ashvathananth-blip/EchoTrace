export type MutationKind =
  | "faithful"
  | "causation"
  | "certainty"
  | "context"
  | "exaggeration"
  | "attribution"
  | "scope"
  | "quantifier"
  | "omission"
  | "addition";

export type Direction = "up" | "down" | "shift";

export type Engine = "curated" | "heuristic" | "anthropic";

export interface Evidence {
  removed: string[];
  added: string[];
  note?: string;
}

export interface Mutation {
  kind: MutationKind;
  severity: number;
  label: string;
  explanation: string;
  direction?: Direction;
  evidence: Evidence;
}

export interface StatementNode {
  id: string;
  parentId: string | null;
  text: string;
  mutations: Mutation[];
  source: Engine;
}

export interface Chain {
  id: string;
  title: string;
  original: string;
  nodes: StatementNode[];
  verdict: string;
  engine: Engine;
  message?: string;
}

export interface RewriteInput {
  id: string;
  text: string;
  parentId: string;
}

export interface AnalyzeRequest {
  original: string;
  rewrites: RewriteInput[];
}
