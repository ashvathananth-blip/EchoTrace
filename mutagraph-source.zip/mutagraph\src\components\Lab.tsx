"use client";

import dynamic from "next/dynamic";
import { useCallback, useEffect, useMemo, useState } from "react";
import Composer from "./Composer";
import Inspector from "./Inspector";
import Legend from "./Legend";
import { EXAMPLES } from "@/lib/examples";
import { ancestryIds, bandFor, deepestNode, driftScore, pathTo } from "@/lib/graph";
import { buildShareUrl, decodeChain } from "@/lib/share";
import type { Chain } from "@/lib/types";

const Graph = dynamic(() => import("./Graph"), {
  ssr: false,
  loading: () => <div className="canvas-loading">Laying out the mutation graph…</div>,
});

function chainDrift(chain: Chain): number {
  return chain.nodes.reduce(
    (max, node) => Math.max(max, driftScore(pathTo(node.id, chain.nodes))),
    0,
  );
}

function engineLabel(engine: Chain["engine"]): string {
  if (engine === "anthropic") return "Model analysis";
  if (engine === "heuristic") return "Offline engine";
  return "Curated chain";
}

function AboutModal({ onClose }: { onClose: () => void }) {
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  return (
    <div className="modal-backdrop" onClick={onClose} role="presentation">
      <div
        className="modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="about-title"
        onClick={(event) => event.stopPropagation()}
      >
        <button type="button" className="modal-close" onClick={onClose} aria-label="Close">
          ×
        </button>
        <h2 id="about-title">How Mutagraph works</h2>
        <ol>
          <li>
            <strong>Start with a real sentence.</strong> A finding, a statistic, a
            statement someone actually made.
          </li>
          <li>
            <strong>Add the versions it turned into.</strong> Each rewrite points at the
            statement it came from, so a chain can branch.
          </li>
          <li>
            <strong>Every pair is compared word by word.</strong> The word diff shows what
            was removed and added; the classifier names the linguistic move — a causal
            verb where there was an association, a hedge turned into proof, a study
            replaced by "scientists".
          </li>
          <li>
            <strong>Drift compounds.</strong> Each transformation is scored 0–100 by how
            much it changes what a reader would conclude. Scores multiply along a path,
            so a small omission plus a small exaggeration lands further out than either
            alone.
          </li>
          <li>
            <strong>Inspect the words.</strong> Hover a transformation to light up the
            exact tokens responsible in the diff. Nothing in the explanation is
            unaccounted for.
          </li>
        </ol>

        <h3>What the bands mean</h3>
        <p>
          <strong>Faithful</strong> (0–11) keeps the source&apos;s strength, scope and
          caveats. <strong>Drifted</strong> (12–39) loses a qualifier or two.{" "}
          <strong>Distorted</strong> (40–69) asserts more than the evidence carries.{" "}
          <strong>Detached</strong> (70+) is a different claim wearing the original&apos;s
          clothes.
        </p>

        <h3>Honesty notes</h3>
        <p>
          The six example chains are written for demonstration, not copied from published
          papers. The transformations are the ones that recur constantly in health,
          science and technology reporting; the sentences were authored so each one can
          be shown exactly.
        </p>
        <p>
          This is not a fact-checker. It does not tell you whether a claim is true — it
          shows what happened to the claim between the evidence and the headline. A
          rewrite can drift and still be right; a faithful paraphrase of a bad study is
          still a bad study.
        </p>
      </div>
    </div>
  );
}

export default function Lab() {
  const [chain, setChain] = useState<Chain>(EXAMPLES[0]);
  const [selectedId, setSelectedId] = useState<string>(() => deepestNode(EXAMPLES[0]).id);
  const [playing, setPlaying] = useState(false);
  const [aboutOpen, setAboutOpen] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [shared, setShared] = useState(false);

  useEffect(() => {
    const hash = window.location.hash;
    if (!hash.startsWith("#c=")) return;
    const decoded = decodeChain(hash.slice(3));
    if (!decoded) return;
    setChain(decoded);
    setSelectedId(deepestNode(decoded).id);
    setShared(true);
  }, []);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 2600);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const playback = useMemo(
    () => ancestryIds(deepestNode(chain).id, chain.nodes),
    [chain],
  );

  useEffect(() => {
    if (!playing) return;
    const index = playback.indexOf(selectedId);
    if (index === -1 || index >= playback.length - 1) {
      setPlaying(false);
      return;
    }
    const timer = window.setTimeout(() => {
      setSelectedId(playback[index + 1]);
    }, 1500);
    return () => window.clearTimeout(timer);
  }, [playing, playback, selectedId]);

  const handleSelect = useCallback((id: string) => {
    setPlaying(false);
    setSelectedId(id);
  }, []);

  const handleChain = useCallback((next: Chain) => {
    setChain(next);
    setPlaying(false);
    setShared(false);
    setSelectedId(deepestNode(next).id);
    if (typeof window !== "undefined") {
      window.history.replaceState(null, "", window.location.pathname);
    }
    setToast(
      next.engine === "anthropic"
        ? "Compared with the model"
        : "Compared with the offline engine",
    );
  }, []);

  const openExample = useCallback((example: Chain) => {
    setChain(example);
    setSelectedId(deepestNode(example).id);
    setPlaying(false);
    setShared(false);
    if (typeof window !== "undefined") {
      window.history.replaceState(null, "", window.location.pathname);
    }
  }, []);

  const startPlayback = () => {
    if (playing) {
      setPlaying(false);
      return;
    }
    setSelectedId(chain.nodes[0]?.id ?? "root");
    setPlaying(true);
  };

  const copyLink = async () => {
    const url = buildShareUrl(chain);
    try {
      await navigator.clipboard.writeText(url);
      setToast("Permalink copied — it carries the whole graph");
    } catch {
      window.prompt("Copy this link", url);
    }
  };

  const selected = chain.nodes.find((node) => node.id === selectedId) ?? chain.nodes[0];
  const drift = selected ? driftScore(pathTo(selected.id, chain.nodes)) : 0;
  const band = bandFor(drift);

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">
          <span className="brand-mark" aria-hidden>
            ⌁
          </span>
          <div>
            <h1>Mutagraph</h1>
            <p>Trace how a true sentence becomes a misleading one</p>
          </div>
        </div>
        <div className="topbar-actions">
          <span className={`engine-badge ${chain.engine}`}>{engineLabel(chain.engine)}</span>
          <span className={`engine-badge band-${band.key}`}>{band.label}</span>
          <button type="button" className="btn small" onClick={copyLink}>
            Copy permalink
          </button>
          <button type="button" className="btn small" onClick={() => setAboutOpen(true)}>
            How it works
          </button>
        </div>
      </header>

      {shared ? (
        <div className="link-banner">
          <span>Viewing a shared chain.</span>
          <button type="button" onClick={() => openExample(EXAMPLES[0])}>
            Back to the examples
          </button>
        </div>
      ) : null}

      <main className="shell">
        <aside className="rail">
          <section className="rail-block">
            <div className="rail-head">
              <h2>Example chains</h2>
              <span className="rail-count">{EXAMPLES.length}</span>
            </div>
            <ul className="example-list">
              {EXAMPLES.map((example) => {
                const exampleDrift = chainDrift(example);
                const exampleBand = bandFor(exampleDrift);
                const isActive = example.id === chain.id;
                return (
                  <li key={example.id}>
                    <button
                      type="button"
                      className={`example${isActive ? " is-active" : ""}`}
                      onClick={() => openExample(example)}
                      aria-current={isActive}
                    >
                      <span className="example-title">{example.title}</span>
                      <span className="example-verdict">{example.verdict}</span>
                      <span className="example-meta">
                        <span className="mini-track">
                          <span
                            style={{
                              width: `${Math.max(4, exampleDrift)}%`,
                              background: exampleBand.color,
                            }}
                          />
                        </span>
                        <span style={{ color: exampleBand.color }}>{exampleBand.label}</span>
                      </span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </section>

          <section className="rail-block">
            <Composer onChain={handleChain} />
          </section>

          <section className="rail-block">
            <Legend />
          </section>
        </aside>

        <section className="stage">
          <div className="stage-head">
            <div>
              <span className="eyebrow">{engineLabel(chain.engine)}</span>
              <h2>{chain.title}</h2>
              <p className="verdict">{chain.verdict}</p>
            </div>
            <div className="stage-actions">
              <button type="button" className="btn primary" onClick={startPlayback}>
                {playing ? "■ Stop" : "▶ Play the mutation"}
              </button>
            </div>
          </div>

          <div className="canvas">
            <Graph
              key={`${chain.id}-${chain.nodes.map((node) => node.id).join("-")}`}
              chain={chain}
              selectedId={selectedId}
              onSelect={handleSelect}
            />
            <p className="canvas-hint">
              Click a branch · hover a transformation to light up the responsible words
            </p>
          </div>
        </section>

        <aside className="inspector-col">
          <Inspector
            key={`${chain.id}-${selectedId}`}
            chain={chain}
            nodeId={selectedId}
            onSelect={handleSelect}
          />
        </aside>
      </main>

      {toast ? <div className="toast">{toast}</div> : null}
      {aboutOpen ? <AboutModal onClose={() => setAboutOpen(false)} /> : null}
    </div>
  );
}
