import { NextResponse } from "next/server";
import { buildChain, describeArc } from "@/lib/analyze";
import { classifyEdges, type ClassifyEdge } from "@/lib/anthropic";
import { deepestNode, pathTo } from "@/lib/graph";
import type { AnalyzeRequest, Chain, Mutation, RewriteInput } from "@/lib/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const MAX_TEXT = 700;
const MAX_REWRITES = 6;
const WINDOW_MS = 60_000;
const WINDOW_LIMIT = 20;

const hits = new Map<string, { count: number; resetAt: number }>();

function rateLimited(request: Request): boolean {
  const key =
    request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    request.headers.get("x-real-ip") ||
    "local";
  const now = Date.now();
  const entry = hits.get(key);

  if (!entry || now > entry.resetAt) {
    hits.set(key, { count: 1, resetAt: now + WINDOW_MS });
    if (hits.size > 5000) hits.clear();
    return false;
  }

  entry.count += 1;
  return entry.count > WINDOW_LIMIT;
}

function badRequest(message: string) {
  return NextResponse.json({ error: message }, { status: 400 });
}

export async function POST(request: Request) {
  if (rateLimited(request)) {
    return NextResponse.json(
      { error: "Too many comparisons in a minute. Take a breath and retry." },
      { status: 429 },
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return badRequest("Expected a JSON body.");
  }

  if (!body || typeof body !== "object") return badRequest("Expected a JSON object.");

  const { original: rawOriginal, rewrites: rawRewrites } = body as AnalyzeRequest;

  if (typeof rawOriginal !== "string") return badRequest("An original statement is required.");
  const original = rawOriginal.replace(/\s+/g, " ").trim();
  if (original.length < 12) return badRequest("The original statement is too short to analyse.");
  if (original.length > MAX_TEXT) return badRequest(`Keep the original under ${MAX_TEXT} characters.`);

  if (!Array.isArray(rawRewrites) || rawRewrites.length === 0) {
    return badRequest("Add at least one rewritten version.");
  }
  if (rawRewrites.length > MAX_REWRITES) {
    return badRequest(`At most ${MAX_REWRITES} rewrites can be compared at once.`);
  }

  const seen = new Set<string>(["root"]);
  const rewrites: RewriteInput[] = [];

  for (const [index, raw] of rawRewrites.entries()) {
    if (!raw || typeof raw !== "object") return badRequest("Each rewrite must be an object.");
    const candidate = raw as Partial<RewriteInput>;
    const text = typeof candidate.text === "string" ? candidate.text.replace(/\s+/g, " ").trim() : "";
    if (text.length < 6) return badRequest(`Rewrite ${index + 1} is too short to analyse.`);
    if (text.length > MAX_TEXT) return badRequest(`Keep every rewrite under ${MAX_TEXT} characters.`);

    const id = `r${index + 1}`;
    const requestedParent =
      typeof candidate.parentId === "string" && candidate.parentId.trim()
        ? candidate.parentId.trim()
        : "root";

    const parentId = seen.has(requestedParent) ? requestedParent : "root";

    seen.add(id);
    rewrites.push({ id, text, parentId });
  }

  const chain = buildChain({

    id: `custom-${Date.now().toString(36)}`,

    title: original.length > 62 ? `${original.slice(0, 59)}…` : original,
    original,
    rewrites,
    engine: "heuristic",
  });

  const edges: ClassifyEdge[] = chain.nodes
    .filter((node) => node.parentId)
    .map((node) => ({
      id: node.id,
      parentText: chain.nodes.find((parent) => parent.id === node.parentId)?.text ?? original,
      text: node.text,
    }));

  let engine: Chain["engine"] = "heuristic";
  let message: string | undefined;

  if (!process.env.ANTHROPIC_API_KEY) {
    message =
      "Offline engine: no ANTHROPIC_API_KEY is set, so transformations were detected with the built-in linguistic analyser.";
  } else {
    const result = await classifyEdges(edges);
    if (result) {
      engine = "anthropic";
      for (const node of chain.nodes) {
        const mutations = result.edges.get(node.id);
        if (mutations && mutations.length > 0) node.mutations = mutations;
        node.source = "anthropic";
      }
    } else {
      message =
        "The model call failed or returned nothing usable, so the offline engine was used instead.";
    }
  }

  chain.engine = engine;
  chain.message = message;

  const target = deepestNode(chain);
  const path: Mutation[] = pathTo(target.id, chain.nodes);
  chain.verdict = describeArc(path);

  return NextResponse.json({ chain, engine });
}
